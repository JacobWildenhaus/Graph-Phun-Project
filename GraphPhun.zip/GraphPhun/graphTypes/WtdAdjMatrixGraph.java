package graphTypes;

import graphDraw.Segment;

public class WtdAdjMatrixGraph extends GraphADT {

	@Override
	public Iterable<Segment> segmentIterable() {
		
		return null;
	}

	@Override
	public int addVertex() {
		return 0;
	}

	@Override
	public void addEdge(int v0, int v1) {

	}

	@Override
	public void addRandomEdge() {

	}

	@Override
	public boolean hasEdge(int v0, int v1) {
		return false;
	}

	@Override
	public boolean hasPath(int v0, int v1) {
		return false;
	}

	@Override
	public boolean connected() {
		return false;
	}

	@Override
	public boolean isIsomorphic(GraphADT g) {
		return false;
	}

	@Override
	public GraphADT dfsGraph() {
		return null;
	}

	@Override
	public GraphADT bfsGraph() {
		return null;
	}

	public static void main(String[] args) {

	}

}
