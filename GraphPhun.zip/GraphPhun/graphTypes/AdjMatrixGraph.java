package graphTypes;

import java.awt.Color;
import graphDraw.*;
import java.util.ArrayList;

public class AdjMatrixGraph extends GraphADT {
	boolean[][] adjMatrix;
	ArrayList<Segment> segments;
	ArrayList<Point> coords;
	Point[] pointList;
	
	
	public AdjMatrixGraph(int nVerts) {
		super(nVerts);
		this.coords = super.coords;
		
		segments = new ArrayList<Segment>();
		adjMatrix = new boolean [nVerts][nVerts];
	}
	
	public AdjMatrixGraph(int nVerts, ArrayList<Point> coords) {
		super(nVerts, coords);
	}
	
	@Override
	public Iterable<Segment> segmentIterable() {
		
		return segments;
	}

	@Override
	public int addVertex() {

		return 0;
	}

	@Override
	public void addEdge(int v0, int v1) {
		this.segments.add(new Segment(coords.get(v0), coords.get(v1)));

	}

	@Override
	public void addRandomEdge() {
		

	}

	@Override
	public boolean hasEdge(int v0, int v1) {
		
		return (v0 == 0 && v1 == 1) || (v0 == 1 && v1 == 0);
	}

	@Override
	public boolean hasPath(int v0, int v1) {
	
		return false;
	}

	@Override
	public boolean connected() {
		
		return false;
	}

	@Override
	public boolean isIsomorphic(GraphADT g) {
	
		return false;
	}

	@Override
	public GraphADT dfsGraph() {
		
		return this;
	}

	@Override
	public GraphADT bfsGraph() {
		super.visited = new ArrayList<Point>();
		Point a = coords.get(0);
		super.visited.add(a);
		Point b = coords.get(1);
		Point c = new Point();
		
		while(super.visited.size() != coords.size()) {
			if(a==b) {
				b=c;
			}
			for(int i = 0; i < coords.size(); i++) {
					c = coords.get(i);
					if(a.dist(b) > a.dist(c) && (a!=b) && (a!=c) && (b!=c) && !super.visited.contains(c) && !super.visited.contains(b)) { 
						b=c;
					}
			}
			
			this.segments.add(new Segment(a, b));
			super.visited.add(b);
			System.out.println(segments.size() + " Segments");
			System.out.println(visited.size() + " Visited Points");
			a = b;
		}
		System.out.println(visited);
		return this;
	}

	public static void main(String[] args) {

	}
}
