/**
 * 
 */
package graphTypes;

/**
 * @author Jacob Wildenhaus
 *
 */
public interface EdgeWeighted {

	double edgeWeight(int v0, int v1);
	
}
