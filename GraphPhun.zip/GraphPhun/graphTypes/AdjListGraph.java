package graphTypes;

import graphDraw.*;
import java.util.ArrayList;

public class AdjListGraph extends GraphADT {
	ArrayList<ArrayList<Integer>> adjList;
	ArrayList<Point> coords;
	ArrayList<Segment> segments;

	public AdjListGraph(int nVerts) {
		super(nVerts);
		this.coords = super.coords;
		
		segments = new ArrayList<Segment>();
		
	}
	
	public AdjListGraph(int nVerts, ArrayList<Point> coords) {
		super(nVerts, coords);
	}
	
	@Override
	public Iterable<Segment> segmentIterable() {
		
		return segments;
	}

	@Override
	public int addVertex() {
		
		return 0;
	}

	@Override
	public void addEdge(int v0, int v1) {
		

	}

	@Override
	public void addRandomEdge() {
		

	}

	@Override
	public boolean hasEdge(int v0, int v1) {
		
		return (v0 == 0 && v1 == 1) || (v0 == 1 && v1 == 0);
	}

	@Override
	public boolean hasPath(int v0, int v1) {
		
		return false;
	}

	@Override
	public boolean connected() {
		
		return false;
	}

	@Override
	public boolean isIsomorphic(GraphADT g) {
		
		return false;
	}

	@Override
	public GraphADT dfsGraph() {
		
		return this;
	}

	@Override
	public GraphADT bfsGraph() {
		
		return this;
	}

	public static void main(String[] args) {
		
	

	}

}
